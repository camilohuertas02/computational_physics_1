# include <iostream >

using namespace std ;


int main (void ) {

double PI = 3.1415926535897932;
double R = 4.0;


cout << "\n Perimeter= " << 2.0 * PI * R << "\n";
cout << " Area= " << PI * R * R << "\n";



return 0;
}